import{_ as e,W as t,X as c}from"./framework-a2435a15.js";const n={};function _(r,o){return t(),c("div")}const a=e(n,[["render",_],["__file","index.html.vue"]]);export{a as default};
