import{Z as t,_ as n,$ as o}from"./mermaid.core-4f366cb1.js";function a(e){return typeof e=="string"?new t([document.querySelectorAll(e)],[document.documentElement]):new t([o(e)],n)}export{a as s};
