import{_ as e,W as t,X as _}from"./framework-b57ab25f.js";const c={};function r(n,o){return t(),_("div")}const a=e(c,[["render",r],["__file","404.html.vue"]]);export{a as default};
